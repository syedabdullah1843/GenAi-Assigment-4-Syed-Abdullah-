# Task 5: Create Product Info File using User Input

products = []

for i in range(3):
    name = input(f"Enter product {i + 1} name: ")
    price = float(input(f"Enter price for {name}: "))
    products.append((name, price))

with open("Products.txt", "w") as file:
    for name, price in products:
        file.write(f"{name} | {price:.2f}\n")

print("\nProduct information:")
with open("Products.txt", "r") as file:
    for line in file:
        print(line.strip())
