GENAI ASSIGNMENT 4 - FILE HANDLING
Student: Syed Abdullah

OVERVIEW
This folder contains all seven Python tasks from Assignment 4: File Handling.
The assignment uses basic Python file handling and avoids pandas, the csv module,
and other external libraries.

FOLDER CONTENTS
1. task1_write_sales.py
2. task2_read_sales.py
3. task3_append_sales.py
4. task4_summary_report.py
5. task5_product_info.py
6. task6_safe_file_read.py
7. task7_discounted_prices.py
8. sales_data.txt
9. Products.txt
10. discount_report.txt
11. README.txt

TASK 1 - WRITE SALES RECORDS
- Creates the sales list: 1200, 450, 980, 1500, 3000.
- Opens sales_data.txt in write mode.
- Writes each sale on a separate line.
- Reopens the file in read mode and prints its contents.

TASK 2 - READ FILE IN DIFFERENT WAYS
- Uses read() to read the complete file.
- Uses readline() to read the first line.
- Uses readlines() to read all lines.
- Removes newline characters and converts the values to integers.

TASK 3 - APPEND NEW SALES
- Appends 5000, 2500, and 1700 to sales_data.txt.
- Reopens and prints the updated file.
- Also prints the total number of lines.

TASK 4 - GENERATE SUMMARY REPORT
- Reads all sales values from sales_data.txt.
- Converts the values to integers.
- Calculates total sales, highest sale, lowest sale, and average sale.
- Uses only basic Python operations and file reading.

With the supplied completed sales_data.txt:
Total Sales = 15330
Highest Sale = 5000
Lowest Sale = 450
Average Sale = 1916.25

TASK 5 - CREATE PRODUCT INFO FILE
- Asks the user for three product names and prices.
- Writes the information to Products.txt in the format:
  ProductName | Price
- Reads the file and prints each line with formatting.

TASK 6 - READ FILE SAFELY
- Asks the user for a filename.
- Uses os.path.exists() to check whether the file exists.
- If it exists, the program reads and prints it.
- Otherwise it prints:
  File not found. Please check the filename.

TASK 7 - MINI PROJECT: EXPORT DISCOUNTED PRICES
- Uses the required product-price dictionary.
- Asks the user for a discount percentage.
- Calculates discounted prices.
- Writes the results to discount_report.txt using:
  Product | Original Price | Discounted Price
- Adds Total Items and Average Discounted Price to the report.
- Reads the report and prints it to the terminal.

HOW TO RUN
Open a terminal inside this folder and run each file separately, for example:

python task1_write_sales.py
python task2_read_sales.py
python task3_append_sales.py
python task4_summary_report.py
python task5_product_info.py
python task6_safe_file_read.py
python task7_discounted_prices.py

IMPORTANT RUN ORDER
For a clean demonstration, run Task 1 first and then Task 2, Task 3, and Task 4.
Task 3 appends new values to sales_data.txt, so running it repeatedly will add the
same three values again.

For Task 5, enter any three products and their prices when prompted.
For Task 6, enter a filename such as sales_data.txt.
For Task 7, enter a discount percentage such as 10.

SUBMISSION CHECKLIST
- One main folder.
- All task code files inside the folder.
- README.txt inside the folder.
- Required text files included.
- Folder can be compressed into ZIP format before submission.

NOTE
Review and understand the code and test it yourself before submitting. The assignment
instructions shown in the supplied video state that students should not use AI, so make
sure the submitted work follows your course's academic-integrity requirements.
