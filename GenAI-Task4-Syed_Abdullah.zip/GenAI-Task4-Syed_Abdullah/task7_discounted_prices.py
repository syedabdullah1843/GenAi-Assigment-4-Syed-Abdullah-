# Task 7: Mini Project - Export Discounted Prices

prices = {
    "Mouse": 500,
    "Keyboard": 800,
    "Monitor": 7000,
    "Pendrive": 400,
    "Camera": 5000
}

discount_percentage = float(input("Enter discount percentage: "))

discounted_prices = {}

with open("discount_report.txt", "w") as file:
    file.write("Product | Original Price | Discounted Price\n")
    file.write("-" * 50 + "\n")

    for product, original_price in prices.items():
        discount_amount = original_price * discount_percentage / 100
        discounted_price = original_price - discount_amount
        discounted_prices[product] = discounted_price

        file.write(
            f"{product} | {original_price:.2f} | {discounted_price:.2f}\n"
        )

    total_items = len(discounted_prices)
    average_discounted_price = sum(discounted_prices.values()) / total_items

    file.write("\n")
    file.write(f"Total Items: {total_items}\n")
    file.write(f"Average Discounted Price: {average_discounted_price:.2f}\n")

with open("discount_report.txt", "r") as file:
    print("\nDiscount Report:")
    print(file.read())
