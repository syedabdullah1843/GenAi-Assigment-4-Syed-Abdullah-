# Task 2: Read File in Different Ways

# 1. Read the entire file using read()
with open("sales_data.txt", "r") as file:
    content = file.read()

print("1. Entire file using read():")
print(content)

# 2. Read the first line using readline()
with open("sales_data.txt", "r") as file:
    first_line = file.readline()

print("2. First line using readline():")
print(first_line.strip())

# 3. Read all lines using readlines() and convert to integers
with open("sales_data.txt", "r") as file:
    lines = file.readlines()

sales = [int(line.strip()) for line in lines if line.strip()]

print("3. All lines as a list of integers:")
print(sales)
