# Task 3: Append New Sales

new_sales = [5000, 2500, 1700]

with open("sales_data.txt", "a") as file:
    for sale in new_sales:
        file.write(str(sale) + "\n")

with open("sales_data.txt", "r") as file:
    updated_content = file.read()

print("Updated sales file:")
print(updated_content)

with open("sales_data.txt", "r") as file:
    total_lines = len(file.readlines())

print("Total number of lines:", total_lines)
